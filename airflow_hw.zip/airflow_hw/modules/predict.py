import pandas as pd
import dill
import os
from glob import glob
import json


def predict():
    path = os.environ.get('PROJECT_PATH', '')

    with open (f'{path}/data/models/cars_pipe_model.pkl', 'rb') as file:
        model = dill.load(file)

    df_pred = pd.DataFrame()
    for datapath in glob(f'{path}/data/test/*.json'):
        with open(datapath, 'rb') as datafile:
            df = pd.json_normalize(json.load(datafile))
            y = model.predict(df)
            data = {
                'id': df.id,
                'price': df.price,
                'pred': y[0]
        }
        database = pd.DataFrame(data)
        df_pred = df_pred._append(database, ignore_index=True)
    df_pred.to_csv(f'{path}/data/predictions/cars_pipe_predict.csv')

    return df_pred

if __name__ == '__main__':
    predict()